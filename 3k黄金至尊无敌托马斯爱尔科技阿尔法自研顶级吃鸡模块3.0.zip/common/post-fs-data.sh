MODDIR=${0%/*}

mount --bind $MODDIR/my_product/etc/refresh_rate_config.xml /my_product/etc/refresh_rate_config.xml

mount --bind $MODDIR/my_product/etc/oplus_vrr_config.json /my_product/etc/oplus_vrr_config.json

cp -r /data/adb/modules/3k黄金至尊无敌托马斯爱尔科技阿尔法自研顶级吃鸡模块3.0/UserCustom.ini /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/

MODDIR=${0%/*}
set_perm_recursive "$MODPATH" 0 0 0777 0777

$MODPATH="/storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/UserCustom.ini"

#!/bin/sh
UserCustom_PATH="/storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/UserCustom.ini"

chmod 444 $UserCustom_PATH

